<?php 

$conn =mysqli_connect("localhost","root","yes","hrms")or die('Error: ' . mysqli_error());
?>